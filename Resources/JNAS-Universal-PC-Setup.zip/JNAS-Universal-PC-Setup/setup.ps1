[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$SetupRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Section([string]$Message) {
    Write-Host ""
    Write-Host "=== $Message ===" -ForegroundColor Cyan
}

function Read-RequiredValue([string]$Prompt, [string]$Default = "") {
    while ($true) {
        if ($Default) {
            $value = Read-Host "$Prompt [$Default]"
            if ([string]::IsNullOrWhiteSpace($value)) { $value = $Default }
        } else {
            $value = Read-Host $Prompt
        }
        if (-not [string]::IsNullOrWhiteSpace($value)) { return $value.Trim() }
        Write-Host "This value is required." -ForegroundColor Yellow
    }
}

function Invoke-WingetInstall([string]$Id, [string]$Name) {
    $existing = winget list --id $Id --exact --accept-source-agreements 2>$null | Out-String
    if ($LASTEXITCODE -eq 0 -and $existing -match [regex]::Escape($Id)) {
        Write-Host "Already installed: $Name ($Id)" -ForegroundColor Green
        return
    }

    Write-Host "Installing: $Name ($Id)" -ForegroundColor Yellow
    winget install --id $Id --exact --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "winget returned exit code $LASTEXITCODE for $Name. Review the output; continuing with remaining setup."
    }
}

function Add-SshHostBlock([string]$ConfigPath, [string]$Alias, [string]$KeyPath) {
    $content = ""
    if (Test-Path $ConfigPath) { $content = Get-Content -Raw -LiteralPath $ConfigPath }
    if ($content -match "(?im)^\s*Host\s+$([regex]::Escape($Alias))\s*$") {
        Write-Host "SSH alias already exists: $Alias" -ForegroundColor Green
        return
    }

    $block = @"

# JNAS setup - $Alias
Host $Alias
    HostName github.com
    User git
    IdentityFile "$KeyPath"
    IdentitiesOnly yes
"@
    Add-Content -LiteralPath $ConfigPath -Value $block
    Write-Host "Added SSH alias: $Alias" -ForegroundColor Green
}

Write-Section "System check"
$os = Get-CimInstance Win32_OperatingSystem
Write-Host "Windows: $($os.Caption) ($($os.OSArchitecture))"
Write-Host "PowerShell: $($PSVersionTable.PSVersion)"

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "winget was not found. Install or update 'App Installer' from Microsoft Store, reopen PowerShell, and rerun setup.ps1."
}

$toolsPath = Join-Path $SetupRoot "config\tools.json"
$repoPath = Join-Path $SetupRoot "config\repositories.json"
$extensionsPath = Join-Path $SetupRoot "config\extensions.json"
$toolsConfig = Get-Content $toolsPath -Raw | ConvertFrom-Json
$repoConfig = Get-Content $repoPath -Raw | ConvertFrom-Json
$extensionsConfig = Get-Content $extensionsPath -Raw | ConvertFrom-Json

Write-Section "Install configured applications"
foreach ($tool in $toolsConfig.tools) {
    if ($tool.enabled -eq $true) {
        Invoke-WingetInstall -Id $tool.id -Name $tool.name
    }
}

# Refresh PATH for this PowerShell process after installs.
$machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
$env:Path = "$machinePath;$userPath"

Write-Section "Workspace"
$defaultWorkspace = Join-Path $env:USERPROFILE "Github"
# Reuse the user's existing JNAS workspace when it is present; otherwise use a portable per-user path.
if (Test-Path "C:\Jilanee\Github") { $defaultWorkspace = "C:\Jilanee\Github" }
$workspaceRoot = Read-Host "Workspace folder [$defaultWorkspace] (press Enter to accept)"
if ([string]::IsNullOrWhiteSpace($workspaceRoot)) { $workspaceRoot = $defaultWorkspace }
$workspaceRoot = [Environment]::ExpandEnvironmentVariables($workspaceRoot)
if (-not [System.IO.Path]::IsPathRooted($workspaceRoot)) {
    $workspaceRoot = Join-Path $env:USERPROFILE $workspaceRoot
}
New-Item -ItemType Directory -Path $workspaceRoot -Force | Out-Null
$personalRoot = Join-Path $workspaceRoot "Personal"
$professionalRoot = Join-Path $workspaceRoot "Professional"
New-Item -ItemType Directory -Path $personalRoot,$professionalRoot -Force | Out-Null

$personalName = Read-RequiredValue "Personal Git name" "Jilanee Shaikh"
$personalEmail = Read-RequiredValue "Personal Git email"
$professionalName = Read-RequiredValue "Professional Git name" "Jilanee Shaikh"
$professionalEmail = Read-RequiredValue "Professional Git email"

git config --global user.name $personalName
git config --global user.email $personalEmail
git config --global init.defaultBranch main

$professionalConfig = Join-Path $env:USERPROFILE ".gitconfig-professional"
@"
[user]
    name = $professionalName
    email = $professionalEmail
"@ | Set-Content -LiteralPath $professionalConfig -Encoding UTF8

$includePath = $professionalRoot.Replace("\", "/").TrimEnd("/") + "/"
git config --global --replace-all "includeIf.gitdir/i:$includePath.path" $professionalConfig

Write-Section "Global Git ignore"
$globalIgnore = Join-Path $env:USERPROFILE ".gitignore_global"
$templateIgnore = Join-Path $SetupRoot "templates\gitignore_global"
if (-not (Test-Path $globalIgnore)) {
    Copy-Item $templateIgnore $globalIgnore
} else {
    Write-Host "Existing global ignore file preserved: $globalIgnore"
}
git config --global core.excludesfile $globalIgnore

Write-Section "SSH keys and GitHub aliases"
$sshDir = Join-Path $env:USERPROFILE ".ssh"
New-Item -ItemType Directory -Path $sshDir -Force | Out-Null
$configPath = Join-Path $sshDir "config"

$personalKey = Join-Path $sshDir "id_ed25519_personal"
$professionalKey = Join-Path $sshDir "id_ed25519_professional"

if (-not (Test-Path $personalKey)) {
    Write-Host "Create a passphrase for the Personal SSH key, or press Enter twice for no passphrase."
    ssh-keygen -t ed25519 -C $personalEmail -f $personalKey
} else { Write-Host "Personal SSH key already exists; preserving it." }

if (-not (Test-Path $professionalKey)) {
    Write-Host "Create a passphrase for the Professional SSH key, or press Enter twice for no passphrase."
    ssh-keygen -t ed25519 -C $professionalEmail -f $professionalKey
} else { Write-Host "Professional SSH key already exists; preserving it." }

if (-not (Test-Path $configPath)) { New-Item -ItemType File -Path $configPath -Force | Out-Null }
Add-SshHostBlock -ConfigPath $configPath -Alias "github-personal" -KeyPath $personalKey
Add-SshHostBlock -ConfigPath $configPath -Alias "github-professional" -KeyPath $professionalKey

Write-Host ""
Write-Host "PERSONAL PUBLIC KEY - add this to your Personal GitHub account:" -ForegroundColor Yellow
if (Test-Path "$personalKey.pub") { Get-Content "$personalKey.pub" }
Write-Host ""
Write-Host "PROFESSIONAL PUBLIC KEY - add this to your Professional GitHub account:" -ForegroundColor Yellow
if (Test-Path "$professionalKey.pub") { Get-Content "$professionalKey.pub" }

Write-Section "GitHub SSH authentication"
Write-Host "1. Add the Personal PUBLIC key above to the Personal GitHub account."
Write-Host "2. Add the Professional PUBLIC key above to the Professional GitHub account."
[void](Read-Host "After adding both keys, press Enter to test SSH authentication")

$personalAuth = ssh -T git@github-personal 2>&1 | Out-String
$professionalAuth = ssh -T git@github-professional 2>&1 | Out-String
Write-Host $personalAuth.Trim()
Write-Host $professionalAuth.Trim()

$personalOk = $personalAuth -match "successfully authenticated"
$professionalOk = $professionalAuth -match "successfully authenticated"

if (-not ($personalOk -and $professionalOk)) {
    Write-Warning "One or both SSH tests did not confirm authentication. Repository cloning will be skipped. Add/check the public keys and rerun setup.ps1."
} else {
    Write-Host "Both GitHub accounts authenticated successfully." -ForegroundColor Green
}

Write-Section "Clone configured repositories"
foreach ($repo in $repoConfig.repositories) {
    if (-not ($personalOk -and $professionalOk)) { break }
    if ($repo.enabled -ne $true) { continue }
    $targetBase = if ($repo.account -eq "personal") { $personalRoot } else { $professionalRoot }
    $target = Join-Path $targetBase $repo.folder
    $parent = Split-Path -Parent $target
    New-Item -ItemType Directory -Path $parent -Force | Out-Null

    if (Test-Path (Join-Path $target ".git")) {
        Write-Host "Already cloned; skipping: $target" -ForegroundColor Green
    } elseif (Test-Path $target) {
        $items = @(Get-ChildItem -LiteralPath $target -Force -ErrorAction SilentlyContinue)
        if ($items.Count -eq 0) {
            git clone $repo.url $target
        } else {
            Write-Warning "Target exists and is not empty; not overwriting: $target"
        }
    } else {
        git clone $repo.url $target
    }
}

Write-Section "VS Code extensions"
if (Get-Command code -ErrorAction SilentlyContinue) {
    foreach ($extension in $extensionsConfig.extensions) {
        if ($extension.enabled -eq $true) {
            code --install-extension $extension.id --force
        }
    }
} else {
    Write-Warning "VS Code CLI 'code' was not found in PATH. Open VS Code, enable the command-line launcher if needed, and rerun."
}

Write-Section "Verification"
$report = Join-Path $SetupRoot "setup-report.txt"
@"
JNAS PC Setup Report
Date: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Computer: $env:COMPUTERNAME
Windows: $($os.Caption)
PowerShell: $($PSVersionTable.PSVersion)
Workspace: $workspaceRoot
Git: $((git --version 2>&1 | Out-String).Trim())
Python: $((python --version 2>&1 | Out-String).Trim())
VS Code: $((code --version 2>&1 | Select-Object -First 1 | Out-String).Trim())
"@ | Set-Content -LiteralPath $report -Encoding UTF8

Write-Host "Setup finished. Report: $report" -ForegroundColor Green
Write-Host "Next: add both displayed PUBLIC SSH keys to the matching GitHub accounts, then test SSH authentication."
Write-Host "Run: ssh -T git@github-personal"
Write-Host "Run: ssh -T git@github-professional"
