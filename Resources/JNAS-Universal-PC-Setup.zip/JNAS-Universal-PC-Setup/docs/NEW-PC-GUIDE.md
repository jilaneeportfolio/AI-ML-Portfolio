# New PC restoration guide

## Before leaving the old PC

- Push all project changes to GitHub.
- Confirm every project has a README and dependency manifest (`requirements.txt` or `pyproject.toml`).
- Back up datasets, model weights, local databases, and other files not tracked by Git.
- Record which applications and versions you actually use.
- Keep API keys and credentials in a password manager or another secure method.
- Do not copy private SSH keys into this repository.

## On the new PC

1. Install/update Windows App Installer so `winget` is available.
2. Download and extract JNAS-PC-Setup.
3. Review the JSON configuration files.
4. Open PowerShell in the extracted folder.
5. Run `Set-ExecutionPolicy -Scope Process Bypass -Force`.
6. Run `.\setup.ps1`.
7. Add the two printed public SSH keys to their respective GitHub accounts.
8. Test both SSH aliases.
9. Open each project and recreate its virtual environment from its dependency manifest.
10. Restore large datasets and secrets from their secure backups.

## Manual SSH checks

```powershell
ssh -T git@github-personal
ssh -T git@github-professional
```

## Notes

The setup script preserves existing SSH keys and unrelated SSH config entries. If you already have a `github-personal` or `github-professional` host block with different settings, inspect `~/.ssh/config` manually before rerunning.
