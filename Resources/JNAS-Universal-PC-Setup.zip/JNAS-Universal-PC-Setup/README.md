# JNAS Universal PC Setup (Windows)

A reusable, repeatable Windows 10/11 setup system for your JNAS development environment.

## What it does

- Detects Windows, PowerShell, winget, Git, VS Code and Python.
- Installs configured applications with Windows Package Manager (`winget`).
- Creates a standard workspace under `%USERPROFILE%\Github` by default.
- Configures separate Git identities for Personal and Professional folders.
- Generates separate SSH keys if they do not already exist.
- Adds GitHub SSH host aliases without replacing unrelated SSH configuration.
- Prints public keys that you must manually add to the matching GitHub accounts.
- Installs configured VS Code extensions.
- Clones configured repositories only when the target folder does not already contain a Git repository.
- Writes a setup report.

## Important security and portability rules

1. **Never put private SSH keys, passwords, tokens, API keys, `.env` files, or credentials in this repository.**
2. SSH private keys stay on each computer. This setup generates new keys on each PC.
3. The script cannot safely add SSH keys to GitHub without a separately configured GitHub token. Add each displayed `.pub` key manually in GitHub.
4. GitHub account sign-in in VS Code is separate from Git-over-SSH.
5. Project Python packages are project-specific. Keep a `requirements.txt` or `pyproject.toml` inside each project and install them per project.
6. The setup is idempotent for normal reruns: it skips installed applications, existing keys, existing Git repositories, and existing SSH host blocks.
7. Review `config/*.json` before running. Automatic mode installs every enabled application in `tools.json`.

## Requirements

- Windows 10 (recent build) or Windows 11
- PowerShell 5.1 or PowerShell 7
- Internet connection
- `winget` (App Installer). If unavailable, install/update **App Installer** from Microsoft Store.
- Run from a normal user PowerShell window. Elevation may be requested by winget for some installers.

## Quick start

1. Download/extract this repository on the new PC.
2. Open PowerShell in the extracted folder.
3. Review `config/tools.json`, `config/repositories.json`, and `config/extensions.json`.
4. Run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\setup.ps1
```

5. Follow the prompts for Git names and email addresses.
6. Copy each displayed public SSH key to the corresponding GitHub account:
   - Personal account: GitHub → Settings → SSH and GPG keys → New SSH key
   - Professional account: same page on the other account
7. Test authentication:

```powershell
ssh -T git@github-personal
ssh -T git@github-professional
```

A successful test says authentication succeeded and that GitHub does not provide shell access.

## Configuration

- `config/tools.json`: applications to install using winget.
- `config/repositories.json`: repositories to clone.
- `config/extensions.json`: VS Code extension IDs.
- `templates/gitignore_global`: baseline global Git ignore rules.

Change `workspaceRoot` in `config/repositories.json` if you prefer another location. The default uses the current Windows user's profile, so it works across PCs with different Windows usernames.

## Re-running

Run `.\setup.ps1` again. Existing installs, keys, repositories and SSH aliases are checked before changes are made. If you change an identity email, rerun and enter the updated value.

## Not included automatically

- Copying datasets, model weights, local databases, or large media files
- Restoring API keys or `.env` files
- Installing GPU drivers, CUDA, Docker Desktop, WSL, Ollama, or cloud CLIs
- Configuring application-specific licenses
- Automatically enabling GitHub security settings

These are intentionally separate because they depend on hardware, licensing, account permissions, or secrets.
